import React from 'react'

const ProductSettings = () => {
  return (
    <div>ProductSettings</div>
  )
}

export default ProductSettings