import React from 'react'

const NotComponent = () => {
  return (
    <div>NotComponent</div>
  )
}

export default NotComponent