const UserSettings = () => {
    return (
        <div>
            <h3>User Settings</h3>
            <p>Settings for the user will go here.</p>
        </div>
    );
};
export default UserSettings;