import React from 'react'

const NotComponent = () => {
  return (
    <div>
        <h1>Page not Found</h1>
    </div>
  )
}

export default NotComponent